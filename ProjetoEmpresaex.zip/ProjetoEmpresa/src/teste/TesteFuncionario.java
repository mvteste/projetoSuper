package teste;

import dao.FuncionarioDAO;
import model.Funcionario;

public class TesteFuncionario {

    public static void main(String[] args) {

        FuncionarioDAO dao = new FuncionarioDAO();

        // ==========================
        // TESTE INSERIR
        // ==========================

        /*
        Funcionario f = new Funcionario();

        f.setNome("Maria");
        f.setCpf("11122233344");
        f.setRg("987654");
        f.setData_nascimento("1998-05-20");
        f.setEmail("maria@gmail.com");
        f.setTelefone("55999999999");
        f.setEndereco("Rua B");

        f.setCargo("Gerente");
        f.setSalario(3500);
        f.setData_admissao("2026-06-19");

        dao.inserir(f);

        System.out.println("Funcionário cadastrado!");
        */

        // ==========================
        // TESTE LISTAR
        // ==========================

        /*
        for(Funcionario f : dao.listar()) {

            System.out.println("ID Funcionário: " + f.getId_funcionario());
            System.out.println("Nome: " + f.getNome());
            System.out.println("CPF: " + f.getCpf());
            System.out.println("Cargo: " + f.getCargo());
            System.out.println("Salário: " + f.getSalario());

            System.out.println("---------------------");
        }
        */

        // ==========================
        // TESTE BUSCAR POR ID
        // ==========================

        /*
        Funcionario f = dao.buscarPorId(1);

        if(f != null){

            System.out.println("Nome: " + f.getNome());
            System.out.println("Cargo: " + f.getCargo());
            System.out.println("Salário: " + f.getSalario());

        }else{

            System.out.println("Funcionário não encontrado");

        }
        */

        // ==========================
        // TESTE ATUALIZAR
        // ==========================

        /*
        Funcionario f = dao.buscarPorId(1);

        if(f != null){

            f.setNome("Maria Atualizada");
            f.setCargo("Diretora");
            f.setSalario(5000);

            dao.atualizar(f);

            System.out.println("Funcionário atualizado!");

        }
        */

        // ==========================
        // TESTE DELETE
        // ==========================

        /*
        dao.delete(1);

        System.out.println("Funcionário excluído!");
        */

    }
}