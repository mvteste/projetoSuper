package teste;

import dao.ClienteDAO;
import model.Cliente;

public class TesteCliente {

    public static void main(String[] args) {

        ClienteDAO dao = new ClienteDAO();

        // ==========================
        // TESTE INSERIR
        // ==========================

        /*
        Cliente c = new Cliente();

        c.setNome("Bryan");
        c.setCpf("12345678900");
        c.setRg("1234567");
        c.setData_nascimento("2005-01-01");
        c.setEmail("bryan@gmail.com");
        c.setTelefone("55999999999");
        c.setEndereco("Rua Teste");

        dao.inserir(c);

        System.out.println("Cliente cadastrado!");
        */

        // ==========================
        // TESTE LISTAR
        // ==========================

        /*
        for(Cliente c : dao.listar()) {
            System.out.println("ID Cliente: " + c.getId_cliente());
            System.out.println("Nome: " + c.getNome());
            System.out.println("CPF: " + c.getCpf());
            System.out.println("---------------------");
        }
        */

        // ==========================
        // TESTE BUSCAR POR ID
        // ==========================

        /*
        Cliente c = dao.buscarPorId(1);

        if(c != null){
            System.out.println(c.getNome());
            System.out.println(c.getEmail());
        }
        */

        // ==========================
        // TESTE ATUALIZAR
        // ==========================

        
        Cliente c = dao.buscarPorId(1);

        c.setNome("Bryan Atualizado");
        c.setEmail("novoemail@gmail.com");

        dao.atualizar(c);

        System.out.println("Atualizado!");
        

        // ==========================
        // TESTE DELETE
        // ==========================

        /*
        dao.delete(1);

        System.out.println("Excluído!");
        */
    }
}