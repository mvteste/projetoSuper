package controller;

import dao.ClienteDAO;
import java.util.List;
import model.Cliente;

public class ClienteController {

    private ClienteDAO clienteDAO = new ClienteDAO();

    public List<Cliente> obterClientes() {
        return clienteDAO.listar();
    }

    public void salvarCliente(String nome, String cpf, String rg, String dataNascimento,
            String email, String telefone, String endereco) {

        Cliente c = new Cliente();
        c.setNome(nome);
        c.setCpf(cpf);
        c.setRg(rg);
        c.setData_nascimento(dataNascimento);
        c.setEmail(email);
        c.setTelefone(telefone);
        c.setEndereco(endereco);

        clienteDAO.inserir(c);
    }

    public void atualizarCliente(int idCliente, int idPessoa, String nome, String cpf,
            String email, String telefone) {

        Cliente c = new Cliente();
        c.setId_cliente(idCliente);
        c.setId_pessoa(idPessoa);
        c.setNome(nome);
        c.setCpf(cpf);
        c.setEmail(email);
        c.setTelefone(telefone);

        clienteDAO.atualizar(c);
    }

    public void excluirCliente(int idCliente) {
        clienteDAO.delete(idCliente);
    }

    public Cliente buscarCliente(int idCliente) {
        return clienteDAO.buscarPorId(idCliente);
    }

}//Fim da classe
