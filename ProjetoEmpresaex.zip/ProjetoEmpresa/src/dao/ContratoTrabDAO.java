package dao;

import model.ContratoTrab;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContratoTrabDAO implements GenericDAO<ContratoTrab> {

    @Override
    public void inserir(ContratoTrab c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO contratotrab(id_funcionario, tipo_contrato, carga_horaria, data_inicio, data_fim) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, c.getId_funcionario());
            stmt.setString(2, c.getTipo_contrato());
            stmt.setInt(3, c.getCarga_horaria());
            stmt.setString(4, c.getData_inicio());
            stmt.setString(5, c.getData_fim());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(ContratoTrab c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE contratotrab SET "
                    + "id_funcionario = ?, tipo_contrato = ?, carga_horaria = ?, "
                    + "data_inicio = ?, data_fim = ? "
                    + "WHERE id_contrato = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, c.getId_funcionario());
            stmt.setString(2, c.getTipo_contrato());
            stmt.setInt(3, c.getCarga_horaria());
            stmt.setString(4, c.getData_inicio());
            stmt.setString(5, c.getData_fim());
            stmt.setInt(6, c.getId_contrato());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM contratotrab WHERE id_contrato = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ContratoTrab buscarPorId(int id) {

        ContratoTrab c = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM contratotrab WHERE id_contrato = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                c = new ContratoTrab();

                c.setId_contrato(rs.getInt("id_contrato"));
                c.setId_funcionario(rs.getInt("id_funcionario"));
                c.setTipo_contrato(rs.getString("tipo_contrato"));
                c.setCarga_horaria(rs.getInt("carga_horaria"));
                c.setData_inicio(rs.getString("data_inicio"));
                c.setData_fim(rs.getString("data_fim"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }

    @Override
    public List<ContratoTrab> listar() {

        List<ContratoTrab> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM contratotrab";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ContratoTrab c = new ContratoTrab();

                c.setId_contrato(rs.getInt("id_contrato"));
                c.setId_funcionario(rs.getInt("id_funcionario"));
                c.setTipo_contrato(rs.getString("tipo_contrato"));
                c.setCarga_horaria(rs.getInt("carga_horaria"));
                c.setData_inicio(rs.getString("data_inicio"));
                c.setData_fim(rs.getString("data_fim"));

                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
