package dao;

import model.Estoque;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstoqueDAO implements GenericDAO<Estoque> {

    @Override
    public void inserir(Estoque e) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO estoque(id_produto, quantidade, estoque_minimo) "
                    + "VALUES (?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, e.getId_produto());
            stmt.setInt(2, e.getQuantidade());
            stmt.setInt(3, e.getEstoque_minimo());

            stmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void atualizar(Estoque e) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE estoque SET "
                    + "id_produto = ?, quantidade = ?, estoque_minimo = ? "
                    + "WHERE id_estoque = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, e.getId_produto());
            stmt.setInt(2, e.getQuantidade());
            stmt.setInt(3, e.getEstoque_minimo());
            stmt.setInt(4, e.getId_estoque());

            stmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM estoque WHERE id_estoque = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public Estoque buscarPorId(int id) {

        Estoque e = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM estoque WHERE id_estoque = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                e = new Estoque();

                e.setId_estoque(rs.getInt("id_estoque"));
                e.setId_produto(rs.getInt("id_produto"));
                e.setQuantidade(rs.getInt("quantidade"));
                e.setEstoque_minimo(rs.getInt("estoque_minimo"));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return e;
    }

    @Override
    public List<Estoque> listar() {

        List<Estoque> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM estoque";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Estoque e = new Estoque();

                e.setId_estoque(rs.getInt("id_estoque"));
                e.setId_produto(rs.getInt("id_produto"));
                e.setQuantidade(rs.getInt("quantidade"));
                e.setEstoque_minimo(rs.getInt("estoque_minimo"));

                lista.add(e);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return lista;
    }
}
