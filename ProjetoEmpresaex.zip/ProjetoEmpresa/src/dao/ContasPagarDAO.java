package dao;

import model.ContasPagar;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContasPagarDAO implements GenericDAO<ContasPagar> {

    @Override
    public void inserir(ContasPagar c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO contaspagar(descricao, valor, data_vencimento, status_pagamento, id_fornecedor) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, c.getDescricao());
            stmt.setFloat(2, c.getValor());
            stmt.setString(3, c.getData_vencimento());
            stmt.setString(4, c.getStatus_pagamento());
            stmt.setInt(5, c.getId_fornecedor());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(ContasPagar c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE contaspagar SET "
                    + "descricao = ?, valor = ?, data_vencimento = ?, "
                    + "status_pagamento = ?, id_fornecedor = ? "
                    + "WHERE id_conta_pagar = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, c.getDescricao());
            stmt.setFloat(2, c.getValor());
            stmt.setString(3, c.getData_vencimento());
            stmt.setString(4, c.getStatus_pagamento());
            stmt.setInt(5, c.getId_fornecedor());
            stmt.setInt(6, c.getId_conta_pagar());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM contaspagar WHERE id_conta_pagar = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ContasPagar buscarPorId(int id) {

        ContasPagar c = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM contaspagar WHERE id_conta_pagar = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                c = new ContasPagar();

                c.setId_conta_pagar(rs.getInt("id_conta_pagar"));
                c.setDescricao(rs.getString("descricao"));
                c.setValor(rs.getFloat("valor"));
                c.setData_vencimento(rs.getString("data_vencimento"));
                c.setStatus_pagamento(rs.getString("status_pagamento"));
                c.setId_fornecedor(rs.getInt("id_fornecedor"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }

    @Override
    public List<ContasPagar> listar() {

        List<ContasPagar> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM contaspagar";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ContasPagar c = new ContasPagar();

                c.setId_conta_pagar(rs.getInt("id_conta_pagar"));
                c.setDescricao(rs.getString("descricao"));
                c.setValor(rs.getFloat("valor"));
                c.setData_vencimento(rs.getString("data_vencimento"));
                c.setStatus_pagamento(rs.getString("status_pagamento"));
                c.setId_fornecedor(rs.getInt("id_fornecedor"));

                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
