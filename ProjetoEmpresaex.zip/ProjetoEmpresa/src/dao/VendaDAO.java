package dao;

import model.Venda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO implements GenericDAO<Venda> {

    @Override
    public void inserir(Venda v) {

        try (Connection conn = Conexao.conectar()) {

            // data_venda usa o valor padrão do banco (CURRENT_TIMESTAMP)
            String sql =
                    "INSERT INTO venda(id_cliente, id_funcionario, valor_total) "
                    + "VALUES (?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, v.getId_cliente());
            stmt.setInt(2, v.getId_funcionario());
            stmt.setFloat(3, v.getValor_total());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Venda v) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE venda SET "
                    + "id_cliente = ?, id_funcionario = ?, valor_total = ? "
                    + "WHERE id_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, v.getId_cliente());
            stmt.setInt(2, v.getId_funcionario());
            stmt.setFloat(3, v.getValor_total());
            stmt.setInt(4, v.getId_venda());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM venda WHERE id_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Venda buscarPorId(int id) {

        Venda v = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM venda WHERE id_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                v = new Venda();

                v.setId_venda(rs.getInt("id_venda"));
                v.setId_cliente(rs.getInt("id_cliente"));
                v.setId_funcionario(rs.getInt("id_funcionario"));
                v.setData_venda(rs.getString("data_venda"));
                v.setValor_total(rs.getFloat("valor_total"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return v;
    }

    @Override
    public List<Venda> listar() {

        List<Venda> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM venda";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Venda v = new Venda();

                v.setId_venda(rs.getInt("id_venda"));
                v.setId_cliente(rs.getInt("id_cliente"));
                v.setId_funcionario(rs.getInt("id_funcionario"));
                v.setData_venda(rs.getString("data_venda"));
                v.setValor_total(rs.getFloat("valor_total"));

                lista.add(v);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
