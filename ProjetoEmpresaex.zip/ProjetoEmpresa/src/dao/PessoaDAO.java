package dao;

import model.Pessoa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de consulta para a tabela "pessoa".
 *
 * Não implementa GenericDAO de propósito: toda pessoa do sistema deve ser
 * cadastrada como Cliente ou Funcionario (são essas DAOs que fazem o
 * INSERT/UPDATE/DELETE na tabela pessoa, junto com sua tabela específica).
 *
 * Esta classe serve apenas para consultas genéricas, por exemplo quando você
 * precisa só dos dados de uma pessoa sem se importar se ela é cliente ou
 * funcionário.
 */
public class PessoaDAO {

    public Pessoa buscarPorId(int id) {

        Pessoa p = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM pessoa WHERE id_pessoa = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                p = new Pessoa();

                p.setId_pessoa(rs.getInt("id_pessoa"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                p.setRg(rs.getString("rg"));
                p.setData_nascimento(rs.getString("data_nascimento"));
                p.setEmail(rs.getString("email"));
                p.setTelefone(rs.getString("telefone"));
                p.setEndereco(rs.getString("endereco"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return p;
    }

    public List<Pessoa> listar() {

        List<Pessoa> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM pessoa";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Pessoa p = new Pessoa();

                p.setId_pessoa(rs.getInt("id_pessoa"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                p.setRg(rs.getString("rg"));
                p.setData_nascimento(rs.getString("data_nascimento"));
                p.setEmail(rs.getString("email"));
                p.setTelefone(rs.getString("telefone"));
                p.setEndereco(rs.getString("endereco"));

                lista.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
