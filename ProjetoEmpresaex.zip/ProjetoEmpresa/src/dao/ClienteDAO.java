package dao;

import model.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO implements GenericDAO<Cliente> {

    @Override
    public void inserir(Cliente c) {

        try (Connection conn = Conexao.conectar()) {

            // Inserir Pessoa
            String sqlPessoa =
                    "INSERT INTO pessoa(nome, cpf, rg, data_nascimento, email, telefone, endereco) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement stmtPessoa =
                    conn.prepareStatement(sqlPessoa, Statement.RETURN_GENERATED_KEYS);

            stmtPessoa.setString(1, c.getNome());
            stmtPessoa.setString(2, c.getCpf());
            stmtPessoa.setString(3, c.getRg());
            stmtPessoa.setString(4, c.getData_nascimento());
            stmtPessoa.setString(5, c.getEmail());
            stmtPessoa.setString(6, c.getTelefone());
            stmtPessoa.setString(7, c.getEndereco());

            stmtPessoa.executeUpdate();

            ResultSet rs = stmtPessoa.getGeneratedKeys();

            int idPessoa = 0;

            if (rs.next()) {
                idPessoa = rs.getInt(1);
            }

            // Inserir Cliente
            String sqlCliente =
                    "INSERT INTO cliente(id_pessoa) VALUES (?)";

            PreparedStatement stmtCliente =
                    conn.prepareStatement(sqlCliente);

            stmtCliente.setInt(1, idPessoa);

            stmtCliente.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
public void atualizar(Cliente c) {

    try (Connection conn = Conexao.conectar()) {

        String sql =
                "UPDATE pessoa SET "
                + "nome = ?, "
                + "cpf = ?, "
                + "email = ?, "
                + "telefone = ? "
                + "WHERE id_pessoa = ?";

        PreparedStatement stmt =
                conn.prepareStatement(sql);

        stmt.setString(1, c.getNome());
        stmt.setString(2, c.getCpf());
        stmt.setString(3, c.getEmail());
        stmt.setString(4, c.getTelefone());
        stmt.setInt(5, c.getId_pessoa());

        stmt.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
}

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            // Buscar id_pessoa
            String sqlBusca =
                    "SELECT id_pessoa FROM cliente WHERE id_cliente = ?";

            PreparedStatement stmtBusca =
                    conn.prepareStatement(sqlBusca);

            stmtBusca.setInt(1, id);

            ResultSet rs = stmtBusca.executeQuery();

            int idPessoa = 0;

            if (rs.next()) {
                idPessoa = rs.getInt("id_pessoa");
            }

            // Excluir cliente
            String sqlCliente =
                    "DELETE FROM cliente WHERE id_cliente = ?";

            PreparedStatement stmtCliente =
                    conn.prepareStatement(sqlCliente);

            stmtCliente.setInt(1, id);

            stmtCliente.executeUpdate();

            // Excluir pessoa
            String sqlPessoa =
                    "DELETE FROM pessoa WHERE id_pessoa = ?";

            PreparedStatement stmtPessoa =
                    conn.prepareStatement(sqlPessoa);

            stmtPessoa.setInt(1, idPessoa);

            stmtPessoa.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Cliente buscarPorId(int id) {

        Cliente c = null;

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "SELECT * FROM cliente c "
                    + "INNER JOIN pessoa p ON c.id_pessoa = p.id_pessoa "
                    + "WHERE c.id_cliente = ?";

            PreparedStatement stmt =
                    conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                c = new Cliente();

                c.setId_cliente(rs.getInt("id_cliente"));
                c.setId_pessoa(rs.getInt("id_pessoa"));
                c.setData_cadastro(rs.getString("data_cadastro"));

                c.setNome(rs.getString("nome"));
                c.setCpf(rs.getString("cpf"));
                c.setRg(rs.getString("rg"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setEmail(rs.getString("email"));
                c.setTelefone(rs.getString("telefone"));
                c.setEndereco(rs.getString("endereco"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }

    @Override
    public List<Cliente> listar() {

        List<Cliente> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "SELECT * FROM cliente c "
                    + "INNER JOIN pessoa p ON c.id_pessoa = p.id_pessoa";

            PreparedStatement stmt =
                    conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Cliente c = new Cliente();

                c.setId_cliente(rs.getInt("id_cliente"));
                c.setId_pessoa(rs.getInt("id_pessoa"));
                c.setData_cadastro(rs.getString("data_cadastro"));

                c.setNome(rs.getString("nome"));
                c.setCpf(rs.getString("cpf"));
                c.setRg(rs.getString("rg"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setEmail(rs.getString("email"));
                c.setTelefone(rs.getString("telefone"));
                c.setEndereco(rs.getString("endereco"));

                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}