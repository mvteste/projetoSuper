package dao;

import model.Produto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO implements GenericDAO<Produto> {

    @Override
    public void inserir(Produto p) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO produto(nome_produto, descricao, preco, id_categoria, id_tipo, id_fornecedor) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, p.getNome_produto());
            stmt.setString(2, p.getDescricao());
            stmt.setFloat(3, p.getPreco());
            stmt.setInt(4, p.getId_categoria());
            stmt.setInt(5, p.getId_tipo());
            stmt.setInt(6, p.getId_fornecedor());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Produto p) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE produto SET "
                    + "nome_produto = ?, descricao = ?, preco = ?, "
                    + "id_categoria = ?, id_tipo = ?, id_fornecedor = ? "
                    + "WHERE id_produto = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, p.getNome_produto());
            stmt.setString(2, p.getDescricao());
            stmt.setFloat(3, p.getPreco());
            stmt.setInt(4, p.getId_categoria());
            stmt.setInt(5, p.getId_tipo());
            stmt.setInt(6, p.getId_fornecedor());
            stmt.setInt(7, p.getId_produto());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM produto WHERE id_produto = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Produto buscarPorId(int id) {

        Produto p = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM produto WHERE id_produto = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                p = new Produto();

                p.setId_produto(rs.getInt("id_produto"));
                p.setNome_produto(rs.getString("nome_produto"));
                p.setDescricao(rs.getString("descricao"));
                p.setPreco(rs.getFloat("preco"));
                p.setId_categoria(rs.getInt("id_categoria"));
                p.setId_tipo(rs.getInt("id_tipo"));
                p.setId_fornecedor(rs.getInt("id_fornecedor"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return p;
    }

    @Override
    public List<Produto> listar() {

        List<Produto> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM produto";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Produto p = new Produto();

                p.setId_produto(rs.getInt("id_produto"));
                p.setNome_produto(rs.getString("nome_produto"));
                p.setDescricao(rs.getString("descricao"));
                p.setPreco(rs.getFloat("preco"));
                p.setId_categoria(rs.getInt("id_categoria"));
                p.setId_tipo(rs.getInt("id_tipo"));
                p.setId_fornecedor(rs.getInt("id_fornecedor"));

                lista.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
