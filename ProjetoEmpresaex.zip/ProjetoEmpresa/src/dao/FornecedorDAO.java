package dao;

import model.Fornecedor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FornecedorDAO implements GenericDAO<Fornecedor> {

    @Override
    public void inserir(Fornecedor f) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO fornecedor(nome_empresa, cnpj, telefone, email, endereco) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, f.getNome_empresa());
            stmt.setString(2, f.getCnpj());
            stmt.setString(3, f.getTelefone());
            stmt.setString(4, f.getEmail());
            stmt.setString(5, f.getEndereco());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Fornecedor f) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE fornecedor SET "
                    + "nome_empresa = ?, cnpj = ?, telefone = ?, email = ?, endereco = ? "
                    + "WHERE id_fornecedor = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, f.getNome_empresa());
            stmt.setString(2, f.getCnpj());
            stmt.setString(3, f.getTelefone());
            stmt.setString(4, f.getEmail());
            stmt.setString(5, f.getEndereco());
            stmt.setInt(6, f.getId_fornecedor());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM fornecedor WHERE id_fornecedor = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Fornecedor buscarPorId(int id) {

        Fornecedor f = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM fornecedor WHERE id_fornecedor = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                f = new Fornecedor();

                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome_empresa(rs.getString("nome_empresa"));
                f.setCnpj(rs.getString("cnpj"));
                f.setTelefone(rs.getString("telefone"));
                f.setEmail(rs.getString("email"));
                f.setEndereco(rs.getString("endereco"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    @Override
    public List<Fornecedor> listar() {

        List<Fornecedor> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM fornecedor";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Fornecedor f = new Fornecedor();

                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome_empresa(rs.getString("nome_empresa"));
                f.setCnpj(rs.getString("cnpj"));
                f.setTelefone(rs.getString("telefone"));
                f.setEmail(rs.getString("email"));
                f.setEndereco(rs.getString("endereco"));

                lista.add(f);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
