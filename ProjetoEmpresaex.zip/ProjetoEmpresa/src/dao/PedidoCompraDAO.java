package dao;

import model.PedidoCompra;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoCompraDAO implements GenericDAO<PedidoCompra> {

    @Override
    public void inserir(PedidoCompra p) {

        try (Connection conn = Conexao.conectar()) {

            // data_pedido usa o valor padrão do banco (CURRENT_TIMESTAMP)
            String sql =
                    "INSERT INTO pedidocompra(id_fornecedor, valor_total) "
                    + "VALUES (?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, p.getId_fornecedor());
            stmt.setFloat(2, p.getValor_total());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(PedidoCompra p) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE pedidocompra SET "
                    + "id_fornecedor = ?, valor_total = ? "
                    + "WHERE id_pedido = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, p.getId_fornecedor());
            stmt.setFloat(2, p.getValor_total());
            stmt.setInt(3, p.getId_pedido());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM pedidocompra WHERE id_pedido = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public PedidoCompra buscarPorId(int id) {

        PedidoCompra p = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM pedidocompra WHERE id_pedido = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                p = new PedidoCompra();

                p.setId_pedido(rs.getInt("id_pedido"));
                p.setId_fornecedor(rs.getInt("id_fornecedor"));
                p.setData_pedido(rs.getString("data_pedido"));
                p.setValor_total(rs.getFloat("valor_total"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return p;
    }

    @Override
    public List<PedidoCompra> listar() {

        List<PedidoCompra> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM pedidocompra";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                PedidoCompra p = new PedidoCompra();

                p.setId_pedido(rs.getInt("id_pedido"));
                p.setId_fornecedor(rs.getInt("id_fornecedor"));
                p.setData_pedido(rs.getString("data_pedido"));
                p.setValor_total(rs.getFloat("valor_total"));

                lista.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
