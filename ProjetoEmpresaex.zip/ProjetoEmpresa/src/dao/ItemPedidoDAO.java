package dao;

import model.ItemPedido;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemPedidoDAO implements GenericDAO<ItemPedido> {

    @Override
    public void inserir(ItemPedido i) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO itempedido(id_pedido, id_produto, quantidade, preco_unitario) "
                    + "VALUES (?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, i.getId_pedido());
            stmt.setInt(2, i.getId_produto());
            stmt.setInt(3, i.getQuantidade());
            stmt.setFloat(4, i.getPreco_unitario());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(ItemPedido i) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE itempedido SET "
                    + "id_pedido = ?, id_produto = ?, quantidade = ?, preco_unitario = ? "
                    + "WHERE id_item = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, i.getId_pedido());
            stmt.setInt(2, i.getId_produto());
            stmt.setInt(3, i.getQuantidade());
            stmt.setFloat(4, i.getPreco_unitario());
            stmt.setInt(5, i.getId_item());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM itempedido WHERE id_item = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ItemPedido buscarPorId(int id) {

        ItemPedido i = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM itempedido WHERE id_item = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                i = new ItemPedido();

                i.setId_item(rs.getInt("id_item"));
                i.setId_pedido(rs.getInt("id_pedido"));
                i.setId_produto(rs.getInt("id_produto"));
                i.setQuantidade(rs.getInt("quantidade"));
                i.setPreco_unitario(rs.getFloat("preco_unitario"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return i;
    }

    @Override
    public List<ItemPedido> listar() {

        List<ItemPedido> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM itempedido";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ItemPedido i = new ItemPedido();

                i.setId_item(rs.getInt("id_item"));
                i.setId_pedido(rs.getInt("id_pedido"));
                i.setId_produto(rs.getInt("id_produto"));
                i.setQuantidade(rs.getInt("quantidade"));
                i.setPreco_unitario(rs.getFloat("preco_unitario"));

                lista.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    /**
     * Lista todos os itens de um pedido específico.
     * Método extra (fora da interface) muito útil na prática,
     * já que normalmente você quer os itens de UM pedido, não de todos.
     */
    public List<ItemPedido> listarPorPedido(int idPedido) {

        List<ItemPedido> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM itempedido WHERE id_pedido = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, idPedido);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ItemPedido i = new ItemPedido();

                i.setId_item(rs.getInt("id_item"));
                i.setId_pedido(rs.getInt("id_pedido"));
                i.setId_produto(rs.getInt("id_produto"));
                i.setQuantidade(rs.getInt("quantidade"));
                i.setPreco_unitario(rs.getFloat("preco_unitario"));

                lista.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
