package dao;

import model.Tipo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoDAO implements GenericDAO<Tipo> {

    @Override
    public void inserir(Tipo t) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "INSERT INTO tipo(nome_tipo) VALUES (?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, t.getNome_tipo());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Tipo t) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "UPDATE tipo SET nome_tipo = ? WHERE id_tipo = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, t.getNome_tipo());
            stmt.setInt(2, t.getId_tipo());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM tipo WHERE id_tipo = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Tipo buscarPorId(int id) {

        Tipo t = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM tipo WHERE id_tipo = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                t = new Tipo();

                t.setId_tipo(rs.getInt("id_tipo"));
                t.setNome_tipo(rs.getString("nome_tipo"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return t;
    }

    @Override
    public List<Tipo> listar() {

        List<Tipo> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM tipo";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Tipo t = new Tipo();

                t.setId_tipo(rs.getInt("id_tipo"));
                t.setNome_tipo(rs.getString("nome_tipo"));

                lista.add(t);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
