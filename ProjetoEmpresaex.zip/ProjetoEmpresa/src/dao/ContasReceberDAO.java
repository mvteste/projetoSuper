package dao;

import model.ContasReceber;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContasReceberDAO implements GenericDAO<ContasReceber> {

    @Override
    public void inserir(ContasReceber c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO contasreceber(descricao, valor, data_vencimento, status_recebimento, id_cliente) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, c.getDescricao());
            stmt.setFloat(2, c.getValor());
            stmt.setString(3, c.getData_vencimento());
            stmt.setString(4, c.getStatus_recebimento());
            stmt.setInt(5, c.getId_cliente());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(ContasReceber c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE contasreceber SET "
                    + "descricao = ?, valor = ?, data_vencimento = ?, "
                    + "status_recebimento = ?, id_cliente = ? "
                    + "WHERE id_conta_receber = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, c.getDescricao());
            stmt.setFloat(2, c.getValor());
            stmt.setString(3, c.getData_vencimento());
            stmt.setString(4, c.getStatus_recebimento());
            stmt.setInt(5, c.getId_cliente());
            stmt.setInt(6, c.getId_conta_receber());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM contasreceber WHERE id_conta_receber = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ContasReceber buscarPorId(int id) {

        ContasReceber c = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM contasreceber WHERE id_conta_receber = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                c = new ContasReceber();

                c.setId_conta_receber(rs.getInt("id_conta_receber"));
                c.setDescricao(rs.getString("descricao"));
                c.setValor(rs.getFloat("valor"));
                c.setData_vencimento(rs.getString("data_vencimento"));
                c.setStatus_recebimento(rs.getString("status_recebimento"));
                c.setId_cliente(rs.getInt("id_cliente"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }

    @Override
    public List<ContasReceber> listar() {

        List<ContasReceber> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM contasreceber";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ContasReceber c = new ContasReceber();

                c.setId_conta_receber(rs.getInt("id_conta_receber"));
                c.setDescricao(rs.getString("descricao"));
                c.setValor(rs.getFloat("valor"));
                c.setData_vencimento(rs.getString("data_vencimento"));
                c.setStatus_recebimento(rs.getString("status_recebimento"));
                c.setId_cliente(rs.getInt("id_cliente"));

                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
