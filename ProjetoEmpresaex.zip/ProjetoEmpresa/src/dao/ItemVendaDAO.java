package dao;

import model.ItemVenda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemVendaDAO implements GenericDAO<ItemVenda> {

    @Override
    public void inserir(ItemVenda i) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO itemvenda(id_venda, id_produto, quantidade, preco_unitario) "
                    + "VALUES (?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, i.getId_venda());
            stmt.setInt(2, i.getId_produto());
            stmt.setInt(3, i.getQuantidade());
            stmt.setFloat(4, i.getPreco_unitario());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(ItemVenda i) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE itemvenda SET "
                    + "id_venda = ?, id_produto = ?, quantidade = ?, preco_unitario = ? "
                    + "WHERE id_item_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, i.getId_venda());
            stmt.setInt(2, i.getId_produto());
            stmt.setInt(3, i.getQuantidade());
            stmt.setFloat(4, i.getPreco_unitario());
            stmt.setInt(5, i.getId_item_venda());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM itemvenda WHERE id_item_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ItemVenda buscarPorId(int id) {

        ItemVenda i = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM itemvenda WHERE id_item_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                i = new ItemVenda();

                i.setId_item_venda(rs.getInt("id_item_venda"));
                i.setId_venda(rs.getInt("id_venda"));
                i.setId_produto(rs.getInt("id_produto"));
                i.setQuantidade(rs.getInt("quantidade"));
                i.setPreco_unitario(rs.getFloat("preco_unitario"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return i;
    }

    @Override
    public List<ItemVenda> listar() {

        List<ItemVenda> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM itemvenda";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ItemVenda i = new ItemVenda();

                i.setId_item_venda(rs.getInt("id_item_venda"));
                i.setId_venda(rs.getInt("id_venda"));
                i.setId_produto(rs.getInt("id_produto"));
                i.setQuantidade(rs.getInt("quantidade"));
                i.setPreco_unitario(rs.getFloat("preco_unitario"));

                lista.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    /**
     * Lista todos os itens de uma venda específica.
     * Método extra (fora da interface), útil pra montar o "carrinho" de uma venda.
     */
    public List<ItemVenda> listarPorVenda(int idVenda) {

        List<ItemVenda> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM itemvenda WHERE id_venda = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, idVenda);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                ItemVenda i = new ItemVenda();

                i.setId_item_venda(rs.getInt("id_item_venda"));
                i.setId_venda(rs.getInt("id_venda"));
                i.setId_produto(rs.getInt("id_produto"));
                i.setQuantidade(rs.getInt("quantidade"));
                i.setPreco_unitario(rs.getFloat("preco_unitario"));

                lista.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
