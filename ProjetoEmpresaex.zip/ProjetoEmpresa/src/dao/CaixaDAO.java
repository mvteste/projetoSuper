package dao;

import model.Caixa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CaixaDAO implements GenericDAO<Caixa> {

    @Override
    public void inserir(Caixa c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "INSERT INTO caixa(tipo_movimento, descricao, valor) "
                    + "VALUES (?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, c.getTipo_movimento());
            stmt.setString(2, c.getDescricao());
            stmt.setFloat(3, c.getValor());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Caixa c) {

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "UPDATE caixa SET "
                    + "tipo_movimento = ?, descricao = ?, valor = ? "
                    + "WHERE id_caixa = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, c.getTipo_movimento());
            stmt.setString(2, c.getDescricao());
            stmt.setFloat(3, c.getValor());
            stmt.setInt(4, c.getId_caixa());

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sql = "DELETE FROM caixa WHERE id_caixa = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Caixa buscarPorId(int id) {

        Caixa c = null;

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM caixa WHERE id_caixa = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                c = new Caixa();

                c.setId_caixa(rs.getInt("id_caixa"));
                c.setData_movimento(rs.getString("data_movimento"));
                c.setTipo_movimento(rs.getString("tipo_movimento"));
                c.setDescricao(rs.getString("descricao"));
                c.setValor(rs.getFloat("valor"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }

    @Override
    public List<Caixa> listar() {

        List<Caixa> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql = "SELECT * FROM caixa";

            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Caixa c = new Caixa();

                c.setId_caixa(rs.getInt("id_caixa"));
                c.setData_movimento(rs.getString("data_movimento"));
                c.setTipo_movimento(rs.getString("tipo_movimento"));
                c.setDescricao(rs.getString("descricao"));
                c.setValor(rs.getFloat("valor"));

                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
