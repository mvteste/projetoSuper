package dao;

import model.Funcionario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO implements GenericDAO<Funcionario> {

    @Override
    public void inserir(Funcionario f) {

        try (Connection conn = Conexao.conectar()) {

            String sqlPessoa =
                    "INSERT INTO pessoa(nome, cpf, rg, data_nascimento, email, telefone, endereco) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement stmtPessoa =
                    conn.prepareStatement(sqlPessoa, Statement.RETURN_GENERATED_KEYS);

            stmtPessoa.setString(1, f.getNome());
            stmtPessoa.setString(2, f.getCpf());
            stmtPessoa.setString(3, f.getRg());
            stmtPessoa.setString(4, f.getData_nascimento());
            stmtPessoa.setString(5, f.getEmail());
            stmtPessoa.setString(6, f.getTelefone());
            stmtPessoa.setString(7, f.getEndereco());

            stmtPessoa.executeUpdate();

            ResultSet rs = stmtPessoa.getGeneratedKeys();

            int idPessoa = 0;

            if (rs.next()) {
                idPessoa = rs.getInt(1);
            }

            String sqlFuncionario =
                    "INSERT INTO funcionario(id_pessoa, cargo, salario, data_admissao) "
                    + "VALUES (?, ?, ?, ?)";

            PreparedStatement stmtFuncionario =
                    conn.prepareStatement(sqlFuncionario);

            stmtFuncionario.setInt(1, idPessoa);
            stmtFuncionario.setString(2, f.getCargo());
            stmtFuncionario.setFloat(3, f.getSalario());
            stmtFuncionario.setString(4, f.getData_admissao());

            stmtFuncionario.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Funcionario f) {

        try (Connection conn = Conexao.conectar()) {

            String sqlPessoa =
                    "UPDATE pessoa SET "
                    + "nome=?, cpf=?, rg=?, data_nascimento=?, "
                    + "email=?, telefone=?, endereco=? "
                    + "WHERE id_pessoa=?";

            PreparedStatement stmtPessoa =
                    conn.prepareStatement(sqlPessoa);

            stmtPessoa.setString(1, f.getNome());
            stmtPessoa.setString(2, f.getCpf());
            stmtPessoa.setString(3, f.getRg());
            stmtPessoa.setString(4, f.getData_nascimento());
            stmtPessoa.setString(5, f.getEmail());
            stmtPessoa.setString(6, f.getTelefone());
            stmtPessoa.setString(7, f.getEndereco());
            stmtPessoa.setInt(8, f.getId_pessoa());

            stmtPessoa.executeUpdate();

            String sqlFuncionario =
                    "UPDATE funcionario SET "
                    + "cargo=?, salario=?, data_admissao=? "
                    + "WHERE id_funcionario=?";

            PreparedStatement stmtFuncionario =
                    conn.prepareStatement(sqlFuncionario);

            stmtFuncionario.setString(1, f.getCargo());
            stmtFuncionario.setFloat(2, f.getSalario());
            stmtFuncionario.setString(3, f.getData_admissao());
            stmtFuncionario.setInt(4, f.getId_funcionario());

            stmtFuncionario.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {

        try (Connection conn = Conexao.conectar()) {

            String sqlBusca =
                    "SELECT id_pessoa FROM funcionario WHERE id_funcionario=?";

            PreparedStatement stmtBusca =
                    conn.prepareStatement(sqlBusca);

            stmtBusca.setInt(1, id);

            ResultSet rs = stmtBusca.executeQuery();

            int idPessoa = 0;

            if (rs.next()) {
                idPessoa = rs.getInt("id_pessoa");
            }

            String sqlFuncionario =
                    "DELETE FROM funcionario WHERE id_funcionario=?";

            PreparedStatement stmtFuncionario =
                    conn.prepareStatement(sqlFuncionario);

            stmtFuncionario.setInt(1, id);

            stmtFuncionario.executeUpdate();

            String sqlPessoa =
                    "DELETE FROM pessoa WHERE id_pessoa=?";

            PreparedStatement stmtPessoa =
                    conn.prepareStatement(sqlPessoa);

            stmtPessoa.setInt(1, idPessoa);

            stmtPessoa.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Funcionario buscarPorId(int id) {

        Funcionario f = null;

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "SELECT * FROM funcionario f "
                    + "INNER JOIN pessoa p ON f.id_pessoa = p.id_pessoa "
                    + "WHERE f.id_funcionario=?";

            PreparedStatement stmt =
                    conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                f = new Funcionario();

                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setId_pessoa(rs.getInt("id_pessoa"));
                f.setCargo(rs.getString("cargo"));
                f.setSalario(rs.getFloat("salario"));
                f.setData_admissao(rs.getString("data_admissao"));

                f.setNome(rs.getString("nome"));
                f.setCpf(rs.getString("cpf"));
                f.setRg(rs.getString("rg"));
                f.setData_nascimento(rs.getString("data_nascimento"));
                f.setEmail(rs.getString("email"));
                f.setTelefone(rs.getString("telefone"));
                f.setEndereco(rs.getString("endereco"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    @Override
    public List<Funcionario> listar() {

        List<Funcionario> lista = new ArrayList<>();

        try (Connection conn = Conexao.conectar()) {

            String sql =
                    "SELECT * FROM funcionario f "
                    + "INNER JOIN pessoa p ON f.id_pessoa = p.id_pessoa";

            PreparedStatement stmt =
                    conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Funcionario f = new Funcionario();

                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setId_pessoa(rs.getInt("id_pessoa"));
                f.setCargo(rs.getString("cargo"));
                f.setSalario(rs.getFloat("salario"));
                f.setData_admissao(rs.getString("data_admissao"));

                f.setNome(rs.getString("nome"));
                f.setCpf(rs.getString("cpf"));
                f.setRg(rs.getString("rg"));
                f.setData_nascimento(rs.getString("data_nascimento"));
                f.setEmail(rs.getString("email"));
                f.setTelefone(rs.getString("telefone"));
                f.setEndereco(rs.getString("endereco"));

                lista.add(f);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}