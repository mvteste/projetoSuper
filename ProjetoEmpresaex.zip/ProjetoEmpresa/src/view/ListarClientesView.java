package view;

import controller.ClienteController;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Cliente;

public class ListarClientesView extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(ListarClientesView.class.getName());

    private final ClienteController clienteController = new ClienteController();

    // Índices das colunas da tabela (facilita manutenção se a ordem mudar)
    private static final int COL_ID_CLIENTE = 0;
    private static final int COL_ID_PESSOA = 1;
    private static final int COL_NOME = 2;
    private static final int COL_CPF = 3;
    private static final int COL_EMAIL = 4;
    private static final int COL_TELEFONE = 5;

    public ListarClientesView() {
        initComponents();
        carregarTabela();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bntAtualizarTabela = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        bntExcluir = new javax.swing.JButton();
        bntSalvarEdicao = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Listar Clientes");

        bntAtualizarTabela.setText("Atualizar Lista");
        bntAtualizarTabela.addActionListener(this::bntAtualizarTabelaActionPerformed);

        tblClientes.setModel(new DefaultTableModel(
            new Object[][]{},
            new String[]{
                "Id Cliente", "Id Pessoa", "Nome", "CPF", "Email", "Telefone"
            }
        ) {
            // As colunas de ID (0 e 1) ficam travadas; o resto é editável direto na célula
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != COL_ID_CLIENTE && column != COL_ID_PESSOA;
            }
        });
        jScrollPane2.setViewportView(tblClientes);

        bntExcluir.setText("Excluir");
        bntExcluir.addActionListener(this::bntExcluirActionPerformed);

        bntSalvarEdicao.setText("Salvar Edição");
        bntSalvarEdicao.addActionListener(this::bntSalvarEdicaoActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);

        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 149, Short.MAX_VALUE)
                        .addComponent(bntSalvarEdicao)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bntExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bntAtualizarTabela)))
                .addContainerGap())
        );

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bntAtualizarTabela)
                    .addComponent(bntExcluir)
                    .addComponent(bntSalvarEdicao))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1);
        pack();
    }
    // </editor-fold>

    // ===========================
    // CARREGAR TABELA
    // ===========================
    private void carregarTabela() {

        DefaultTableModel modelo = (DefaultTableModel) tblClientes.getModel();

        modelo.setRowCount(0);

        for (Cliente c : clienteController.obterClientes()) {

            modelo.addRow(new Object[]{
                c.getId_cliente(),
                c.getId_pessoa(),
                c.getNome(),
                c.getCpf(),
                c.getEmail(),
                c.getTelefone()
            });
        }
    }

    // ===========================
    // ATUALIZAR LISTA (recarrega do banco)
    // ===========================
    private void bntAtualizarTabelaActionPerformed(java.awt.event.ActionEvent evt) {
        carregarTabela();
    }

    // ===========================
    // SALVAR EDIÇÃO (grava no banco a linha selecionada)
    // ===========================
    private void bntSalvarEdicaoActionPerformed(java.awt.event.ActionEvent evt) {

        // Garante que a célula que está sendo editada no momento do clique
        // seja "commitada" antes de lermos os valores da tabela.
        if (tblClientes.isEditing()) {
            tblClientes.getCellEditor().stopCellEditing();
        }

        int linha = tblClientes.getSelectedRow();

        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma linha para atualizar!");
            return;
        }

        try {
            int idCliente = Integer.parseInt(tblClientes.getValueAt(linha, COL_ID_CLIENTE).toString());
            int idPessoa = Integer.parseInt(tblClientes.getValueAt(linha, COL_ID_PESSOA).toString());
            String nome = tblClientes.getValueAt(linha, COL_NOME).toString();
            String cpf = tblClientes.getValueAt(linha, COL_CPF).toString();
            String email = tblClientes.getValueAt(linha, COL_EMAIL).toString();
            String telefone = tblClientes.getValueAt(linha, COL_TELEFONE).toString();

            clienteController.atualizarCliente(idCliente, idPessoa, nome, cpf, email, telefone);

            JOptionPane.showMessageDialog(this, "Cliente atualizado com sucesso!");

            carregarTabela();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar: " + e.getMessage());
            logger.log(java.util.logging.Level.SEVERE, "Erro ao atualizar cliente", e);
        }
    }

    // ===========================
    // EXCLUIR
    // ===========================
    private void bntExcluirActionPerformed(java.awt.event.ActionEvent evt) {

        int linha = tblClientes.getSelectedRow();

        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um registro!");
            return;
        }

        int idCliente = Integer.parseInt(tblClientes.getValueAt(linha, COL_ID_CLIENTE).toString());

        int resposta = JOptionPane.showConfirmDialog(
                this,
                "Tem certeza que deseja excluir este cliente?",
                "Confirmação",
                JOptionPane.YES_NO_OPTION
        );

        if (resposta == JOptionPane.YES_OPTION) {

            try {
                clienteController.excluirCliente(idCliente);

                JOptionPane.showMessageDialog(this, "Excluído com sucesso!");
                carregarTabela();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir: " + e.getMessage());
                logger.log(java.util.logging.Level.SEVERE, "Erro ao excluir cliente", e);
            }
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new ListarClientesView().setVisible(true));
    }

    // Variables declaration
    private javax.swing.JButton bntAtualizarTabela;
    private javax.swing.JButton bntExcluir;
    private javax.swing.JButton bntSalvarEdicao;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblClientes;
}
