package model;

public class ContasReceber {
    private int id_conta_receber;
    private String descricao;
    private float valor;
    private String data_vencimento;
    private String status_recebimento;
    private int id_cliente;

    public int getId_conta_receber() {
        return id_conta_receber;
    }

    public void setId_conta_receber(int id_conta_receber) {
        this.id_conta_receber = id_conta_receber;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getData_vencimento() {
        return data_vencimento;
    }

    public void setData_vencimento(String data_vencimento) {
        this.data_vencimento = data_vencimento;
    }

    public String getStatus_recebimento() {
        return status_recebimento;
    }

    public void setStatus_recebimento(String status_recebimento) {
        this.status_recebimento = status_recebimento;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }
}