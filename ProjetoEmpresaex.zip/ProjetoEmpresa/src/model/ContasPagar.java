package model;

public class ContasPagar {
    private int id_conta_pagar;
    private String descricao;
    private float valor;
    private String data_vencimento;
    private String status_pagamento;
    private int id_fornecedor;

    public int getId_conta_pagar() {
        return id_conta_pagar;
    }

    public void setId_conta_pagar(int id_conta_pagar) {
        this.id_conta_pagar = id_conta_pagar;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getData_vencimento() {
        return data_vencimento;
    }

    public void setData_vencimento(String data_vencimento) {
        this.data_vencimento = data_vencimento;
    }

    public String getStatus_pagamento() {
        return status_pagamento;
    }

    public void setStatus_pagamento(String status_pagamento) {
        this.status_pagamento = status_pagamento;
    }

    public int getId_fornecedor() {
        return id_fornecedor;
    }

    public void setId_fornecedor(int id_fornecedor) {
        this.id_fornecedor = id_fornecedor;
    }
}